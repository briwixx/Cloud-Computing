window.BACKEND_URL = "https://backend-app-f95c20f6fd2d.azurewebsites.net";
