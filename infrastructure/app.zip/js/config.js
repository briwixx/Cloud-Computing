window.BACKEND_URL = "https://backend-app-2537858e6c2b.azurewebsites.net";
