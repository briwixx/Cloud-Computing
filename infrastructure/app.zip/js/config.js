window.BACKEND_URL = "backend-app-39b628a98feb.azurewebsites.net";
