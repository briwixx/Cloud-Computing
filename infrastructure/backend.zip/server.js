var express = require("express");
var sql = require("mssql");

var app = express();
app.use(express.json());

// Récupération de la connection string envoyée par Terraform
var connectionString = process.env.DB_CONNECTION_STRING;

var pool = null;

// Fonction de connexion SQL
function getPool(callback) {
  if (pool) return callback(null, pool);

  sql.connect(connectionString, function (err) {
    if (err) return callback(err);
    pool = sql;
    callback(null, pool);
  });
}

// Route test simple
app.get("/", function (req, res) {
  res.send("Backend Node.js is running");
});

// Ping
app.get("/api/ping", function (req, res) {
  res.json({ message: "pong" });
});

// 🚀 Route pour incrémenter VisitCount
app.post("/api/visit", function (req, res) {
  getPool(function (err, pool) {
    if (err) {
      console.error("SQL connection error:", err);
      return res.status(500).json({ error: "DB connection error" });
    }

    pool.request().query(
      "UPDATE VisitCount SET Count = Count + 1 WHERE Id = 1;",
      function (err2) {
        if (err2) {
          console.error("Update error:", err2);
          return res.status(500).json({ error: "Update error" });
        }

        pool.request().query(
          "SELECT Count FROM VisitCount WHERE Id = 1;",
          function (err3, result) {
            if (err3) {
              console.error("Select error:", err3);
              return res.status(500).json({ error: "Select error" });
            }

            res.json({ count: result.recordset[0].Count });
          }
        );
      }
    );
  });
});

var port = process.env.PORT || 3000;
app.listen(port, function () {
  console.log("Backend running on port " + port);
});
